package com.example.wality_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
